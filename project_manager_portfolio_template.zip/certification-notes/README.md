# Certification Notes

Study notes and quick reference sheets for:

- CAPM  
- ECBA  
- Google Project Management Certification  
