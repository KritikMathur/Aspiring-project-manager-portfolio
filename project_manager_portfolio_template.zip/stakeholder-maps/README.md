# Stakeholder Maps

This folder contains stakeholder analysis and communication plan artifacts.

- **Example**: StakeholderMap_ProjectX.png
