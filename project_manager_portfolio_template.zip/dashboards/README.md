# Dashboards

Upload your dashboard files here (Power BI `.pbix`, Tableau `.twbx`, or Excel `.xlsx`).

- **Example**: `SalesDashboard.pbix`
