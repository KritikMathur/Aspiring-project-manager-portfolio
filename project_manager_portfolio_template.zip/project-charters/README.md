# Project Charters

This folder contains example project charters for simulated projects managed in Agile or Hybrid frameworks.

## Project Charter Template

- **Project Title**:  
- **Objective**:  
- **Scope**:  
- **Stakeholders**:  
- **Milestones**:  
- **Budget**:  
- **Risks**:  
